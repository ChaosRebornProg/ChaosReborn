package control;

public class InputController {
}
