package model.creature.chaotic;

public class Zombie {
}
