package model.spells.chaotic;

public class ChaosShift {
}
