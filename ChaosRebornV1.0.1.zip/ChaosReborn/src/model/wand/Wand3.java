package model.wand;

public class Wand3 extends Wand {
}
