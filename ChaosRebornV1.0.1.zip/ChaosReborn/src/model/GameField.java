package model;

public class GameField {

    private char[][] gameArray = null;

    public GameField (int columns, int rows)
    {
        this.gameArray = new char[columns][rows];
    }



}
