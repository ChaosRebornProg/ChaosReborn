package model.wand;

public class Wand1 extends Wand {
}
