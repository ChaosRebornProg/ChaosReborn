package model.wand;

public class Wand2 extends Wand {
}
