package model.creature;

public abstract class Creature {
}
