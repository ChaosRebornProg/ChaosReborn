package model.spells.chaotic;

public class DestructionOfManticores {
}
