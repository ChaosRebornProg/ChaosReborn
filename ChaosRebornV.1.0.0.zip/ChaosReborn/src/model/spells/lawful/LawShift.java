package model.spells.lawful;

public class LawShift {
}
