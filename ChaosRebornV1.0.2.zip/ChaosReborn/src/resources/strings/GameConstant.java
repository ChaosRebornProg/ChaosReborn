package resources.strings;

public interface GameConstant
{
    public char CHAR_OBSTACLE = 'X';
    public char LEVEL_FLAT = '0';
    public char LEVEL_MEDIUM = '1';
    public char LEVEL_HIGH = '2';

    public int PERCENTAGE_FLAT = 50;
    public int PERCENTAGE_MEDIUM = 25;
    public int PERCENTAGE_HIGH = 15;
    public int PERCENTAGE_OBSTACLE = 10;

    public int MAX_NUMBER = 100;

    public int GAMEFIELD_SIZE_SMALL = 10;
    public int GAMEFIELD_SIZE_MEDIUM = 15;
    public int GAMEFIELD_SIZE_BIG = 20;

    public char CHAR_MANA_SOURCE = 'M';
    public String LINE_BREAK = "\n ---------- \n";
    public String DELIMITER = " ";
    public String SIDE_BORDER = "|";
    public String UPPER_LOWER_BORDER = "-";
}