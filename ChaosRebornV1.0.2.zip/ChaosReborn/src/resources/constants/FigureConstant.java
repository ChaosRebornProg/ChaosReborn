package resources.constants;

public interface FigureConstant
{
    char DEFAULT_SYMBOL = 'W';
}