package model.figure;

import resources.constants.FigureConstant;

public abstract class Figure
{
    private Transform transform = null;

    private char symbol = FigureConstant.DEFAULT_SYMBOL;

    public Figure (Transform transform)
    {
        this.transform = transform;
    }

    public Figure (Transform transform, char symbol)
    {
        this.transform = transform;
        this.symbol = symbol;
    }

    public Transform getTransform ()
    {
        return transform;
    }

    public void setTransform (Transform transform)
    {
        this.transform = transform;
    }

    public char getSymbol ()
    {
        return symbol;
    }

    public void setSymbol (char symbol)
    {
        this.symbol = symbol;
    }
}