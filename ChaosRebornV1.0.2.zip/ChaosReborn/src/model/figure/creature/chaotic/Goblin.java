package model.figure.creature.chaotic;

public class Goblin {
}
