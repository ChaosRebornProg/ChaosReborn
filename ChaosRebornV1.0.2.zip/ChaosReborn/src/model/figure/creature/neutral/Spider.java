package model.figure.creature.neutral;

public class Spider {
}
