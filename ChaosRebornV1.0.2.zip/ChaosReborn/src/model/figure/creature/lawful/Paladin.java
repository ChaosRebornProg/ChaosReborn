package model.figure.creature.lawful;

public class Paladin
{

}