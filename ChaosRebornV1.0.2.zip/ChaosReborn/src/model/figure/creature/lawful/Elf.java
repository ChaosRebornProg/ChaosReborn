package model.figure.creature.lawful;

public class Elf {

}
