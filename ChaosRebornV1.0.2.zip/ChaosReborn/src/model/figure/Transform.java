package model.figure;

public class Transform
{
    private float x = 0;
    private float y = 0;
    private float z = 0;

    public Transform(float x, float y, float z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public boolean equals (Transform transform)
    {
        return ( ( this.getX() == transform.getX() ) && ( this.getY() == transform.getY() ) );
    }

    public void moveX (float distance)
    {
        this.x = this.x + distance;
    }

    public void moveY (float distance)
    {
        this.y = this.y + distance;
    }

    public void moveZ (float distance)
    {
        this.z = this.z + distance;
    }

    public float getX()
    {
        return this.x;
    }

    public void setX (int x)
    {
        this.x = x;
    }

    public float getY()
    {
        return this.y;
    }

    public void setY (int y)
    {
        this.y = y;
    }

    public float getZ()
    {
        return this.z;
    }

    public void setZ (int z)
    {
        this.z = z;
    }

}