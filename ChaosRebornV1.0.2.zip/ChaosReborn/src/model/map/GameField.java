package model.map;

public class GameField
{
    private Tile[][] gameArray = null;

    /**
     * Spielfeld wird ueber ein zweidimensionales Array erzeugt
     * @param columns
     * @param rows
     */
    public GameField (int columns, int rows)
    {
        this.gameArray = new Tile[columns][rows];
    }

    @Override
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        for(int row = 0; row < this.getRow(); row++)
        {
            for(int column = 0; column < this.getColumn(); column++)
            {
                buffer.append(gameArray[row][column].toString());
            }
            buffer.append("\n");
        }

        return buffer.toString();
    }

    /**
     * Pro Zelle im Array wird ein Tile eingefuegt
     * @param tile
     * @param row
     * @param column
     */
    public void setTile (Tile tile, int row, int column)
    {
        this.gameArray[row][column] = tile;
    }

    public int getRow ()
    {
        return this.gameArray.length;
    }

    public int getColumn ()
    {
        return this.gameArray[0].length;
    }
}