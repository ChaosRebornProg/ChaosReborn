package model.map;

public class Tile
{
    private Biome biome = null;

    public Tile (Biome biome)
    {
        this.biome = biome;
    }

    /**
     * Zufaelliges Biom wird ausgesucht - ueber den Index des Enums
     * @param randomNumber
     */
    public Tile (int randomNumber)
    {
        this.biome = Biome.values()[randomNumber];
    }

    @Override
    public String toString ()
    {
        return String.valueOf(this.biome.getSymbol());
    }

    public Biome getBiome ()
    {
        return this.biome;
    }
}