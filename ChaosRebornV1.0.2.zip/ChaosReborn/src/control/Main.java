package control;

import utility.KeyboardReader;
import utility.Logger;

/**
 * Main Klasse zum Ausfuehren des Programms
 */

public class Main
{
    public static void main (String[] args)
    {
        GameMapController gameMapController = new GameMapController();
        InputController.setLastInput(KeyboardReader.read());
        InputController.evaluate(InputController.getLastInput(), gameMapController);
        gameMapController.createGameField();

        Logger.view(gameMapController.showGameMap());
    }


}