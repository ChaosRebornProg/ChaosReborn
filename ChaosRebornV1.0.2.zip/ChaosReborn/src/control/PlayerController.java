package control;

import model.figure.Transform;
import model.figure.player.Player;
import resources.constants.PlayerConstant;

public class PlayerController
{
    private Player player = null;

    public PlayerController ()
    {
        Transform transform = new Transform(0f, 0f;
        this.player = new Player(transform, PlayerConstant.PLAYER_SYMBOL);
    }
}