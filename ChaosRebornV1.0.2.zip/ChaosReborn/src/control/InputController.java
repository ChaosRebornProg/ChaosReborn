package control;

import resources.constants.InputConstant;
import resources.strings.GameConstant;

public class InputController
{
    private static char lastInput = 0;

    /**
     * Moeglichkeiten, die Groesse des Spielfelds zu waehlen
     * @param input
     * @param myGameMapController
     */
    public static void evaluate (char input, GameMapController myGameMapController)
    {
        switch (input)
        {
            case InputConstant.SMALL    :   myGameMapController.init(GameConstant.GAMEFIELD_SIZE_SMALL, GameConstant.GAMEFIELD_SIZE_SMALL);
                                            break;
            case InputConstant.MEDIUM   :   myGameMapController.init(GameConstant.GAMEFIELD_SIZE_MEDIUM, GameConstant.GAMEFIELD_SIZE_MEDIUM);
                                            break;
            case InputConstant.BIG      :   myGameMapController.init(GameConstant.GAMEFIELD_SIZE_BIG, GameConstant.GAMEFIELD_SIZE_BIG);
                                            break;
        }
    }

    public static char getLastInput ()
    {
        return lastInput;
    }

    public static void setLastInput (char lastInput)
    {
        InputController.lastInput = lastInput;
    }
}