package control;

public class CreatureController
{

}