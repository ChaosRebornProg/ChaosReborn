package utility;

import java.util.Scanner;

public class KeyboardReader
{
    /**
     * Die Tastatur wird ausgelesen
     * @return
     */
    public static char read ()
    {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine().charAt(0);
    }
}