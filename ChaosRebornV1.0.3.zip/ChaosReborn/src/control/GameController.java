package control;

public class GameController
{
    private GameMapController mapController = null;
    private PlayerController playerController = null;

    public GameController ()
    {

    }

    public void initGame ()
    {
        this.mapController = new mapController;
        this.playerController = new playerController;
    }
}