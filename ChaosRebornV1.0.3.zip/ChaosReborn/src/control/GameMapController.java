package control;

import model.map.Biome;
import model.map.GameField;
import model.map.Tile;
import resources.constants.GameFieldConstants;
import resources.strings.GameConstant;

import java.util.Random;

public class GameMapController
{
    private GameField gameField = null;
    private Random myRandom = null;

    /**
     * Initialisiert die entsprechenden Variablen der Klasse
     * @param row
     * @param column
     */

    public void init(int row, int column)
    {
        myRandom = new Random();
        this.gameField = new GameField(row, column);
        this.createGameField();
    }

    /**
     * Spielfeld wird erzeugt
     * zufaellige Kacheln werden in den Reihen und Zeilen hinzugefuegt
     */
    public void createGameField ()
    {
        for (int countRow = 0; countRow < this.gameField.getRow(); countRow++)
        {
            for ( int countColumn = 0 ; countColumn < this.gameField.getColumn(); countColumn++)
            {
                this.gameField.setTile(createRandomTile(), countRow, countColumn);
            }
        }
    }

    /**
     * Erzeugen einer zufaelligen Kachel
     * @return
     */
    private Tile createRandomTile ()
    {
        int randomNumber = myRandom.nextInt(GameFieldConstants.MAX_NUMBER);
        if (randomNumber < GameFieldConstants.PERCENTAGE_FLAT)
        {
            return new Tile(Biome.FLAT);
        }
        randomNumber = randomNumber - GameFieldConstants.PERCENTAGE_FLAT;

        if (randomNumber < GameFieldConstants.PERCENTAGE_MEDIUM)
        {
            return new Tile(Biome.MEDIUM);
        }
        randomNumber = randomNumber - GameFieldConstants.PERCENTAGE_MEDIUM;

        if (randomNumber < GameFieldConstants.PERCENTAGE_HIGH)
        {
            return new Tile(Biome.HIGH);
        }
        return new Tile (Biome.OBSTACLE);
    }

    /**
     * Ausgeben des Spielfeldes
     * @return
     */
    public String showGameMap ()
    {
        return this.gameField.toString();
    }













    /**public void fillGameArray ()
    {
        for (int count = 0; count < 10; count++)
        {
            Logger.view(GameConstant.UPPER_LOWER_BORDER);
        }
    }*/
}
