package control;

import model.figure.Transform;
import model.figure.player.Player;
import model.map.GameField;
import resources.constants.GameFieldConstants;
import resources.constants.PlayerConstant;
import utility.Logger;

public class PlayerController
{
    private Player player = null;

    public PlayerController ()
    {
        Transform transform = new Transform(0f, 0f,0f);
        this.player = new Player(transform, PlayerConstant.PLAYER_SYMBOL);
        G
    }

    public Transform getSpawnPosition (boolean upperPlayer)
    {
        GameField.getSelectedMapSize();

        int calculateColumn = (GameField.getSelectedMapSize() / 2 ) + 1;

        if (upperPlayer)
        {
            return new Transform(GameFieldConstants.SPAWN_UPPER_PLAYER_ROW,calculateColumn,0);
        }
        else
        {
            return new Transform(GameFieldConstants.SPAWN_LOWER_PLAYER_ROW, calculateColumn, 0);
        }

    }



}