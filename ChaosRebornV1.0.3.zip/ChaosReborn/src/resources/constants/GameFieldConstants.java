package resources.constants;

import model.map.GameField;

public interface GameFieldConstants {

    public int PERCENTAGE_FLAT = 50;
    public int PERCENTAGE_MEDIUM = 25;
    public int PERCENTAGE_HIGH = 15;
    public int PERCENTAGE_OBSTACLE = 10;

    public int MAX_NUMBER = 100;

    public int GAMEFIELD_SIZE_SMALL = 11;
    public int GAMEFIELD_SIZE_MEDIUM = 15;
    public int GAMEFIELD_SIZE_BIG = 19;

    public int SPAWN_UPPER_PLAYER_ROW = 1;
    public int SPAWN_LOWER_PLAYER_ROW = GameField.getSelectedMapSize() - SPAWN_UPPER_PLAYER_ROW;

}
