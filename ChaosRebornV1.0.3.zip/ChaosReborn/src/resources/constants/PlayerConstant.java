package resources.constants;

public interface PlayerConstant
{
    public int ATTACK_POINTS =1;
    public int DEFEND_POINTS =1;
    public int MOVEMENT_RANGE =1;
    public int MANA_POINTS =1;
    public int HEALTH_POINTS =1;
    public char PLAYER_SYMBOL ='@';
}