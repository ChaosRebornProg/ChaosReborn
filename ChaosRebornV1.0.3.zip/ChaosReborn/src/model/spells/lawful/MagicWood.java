package model.spells.lawful;

public class MagicWood {
}
