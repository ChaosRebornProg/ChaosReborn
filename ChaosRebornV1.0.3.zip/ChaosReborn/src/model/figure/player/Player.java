package model.figure.player;

import model.figure.Figure;
import model.figure.Transform;

public class Player extends Figure
{
    public Player (Transform transform, char symbol)
    {
        super(transform, symbol);
    }
}