package model.figure;

import resources.constants.FigureConstant;

public abstract class Figure
{
    private Transform position = null;

    private char symbol = FigureConstant.DEFAULT_SYMBOL;

    public Figure (Transform position)
    {
        this.position = position;
    }

    public Figure (Transform position, char symbol)
    {
        this.position = position;
        this.symbol = symbol;
    }

    public Transform getPosition()
    {
        return position;
    }

    public void setPosition(Transform position)
    {
        this.position = position;
    }

    public char getSymbol ()
    {
        return symbol;
    }

    public void setSymbol (char symbol)
    {
        this.symbol = symbol;
    }
}