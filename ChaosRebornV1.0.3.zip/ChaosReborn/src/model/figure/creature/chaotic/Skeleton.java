package model.figure.creature.chaotic;

public class Skeleton {
}
