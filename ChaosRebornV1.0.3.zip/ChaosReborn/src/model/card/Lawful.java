package model.card;

public class Lawful extends Card{
}
