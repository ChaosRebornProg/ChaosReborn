package model.map;

import resources.constants.GameFieldConstants;
import resources.strings.GameConstant;

public enum Biome
{
    /**
     * moegliche Ebenen auf dem Spielfeld (Hoehe der Ebene oder Hindernisse)
     */
    FLAT (GameConstant.LEVEL_FLAT, GameFieldConstants.PERCENTAGE_FLAT),
    MEDIUM (GameConstant.LEVEL_MEDIUM, GameFieldConstants.PERCENTAGE_MEDIUM),
    HIGH (GameConstant.LEVEL_HIGH, GameFieldConstants.PERCENTAGE_HIGH),
    OBSTACLE (GameConstant.CHAR_OBSTACLE, GameFieldConstants.PERCENTAGE_OBSTACLE);

    private final char symbol;
    private final int percentageSpawn;

    /**
     * Ausgabesymbole der einzelnen Ebenen
     * @param symbol
     */
    Biome (char symbol, int percentageSpawn)
    {
        this.symbol = symbol;
        this.percentageSpawn = percentageSpawn;
    }

    public char getSymbol ()
    {
        return this.symbol;
    }

    public int getPercentageSpawn ()
    {
        return this.percentageSpawn;
    }
}